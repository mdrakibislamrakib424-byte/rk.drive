RK DRIVE - PHASE 2 / STEP 3b  (forest to the horizon, thick grass, more trees, wind, shadows, quality)
=====================================================================================================
Upload every file to the GAME repo (the one with project.godot), into the SAME folder as in this zip.
Do NOT upload this README. These files come on top of the earlier packages (Phase2_FINAL, Step3, FPS update).

REPLACE (8 files) - overwrite the old version
  scripts/world/scenery_builder.gd   trees (4 kinds), far forest, bushes, grass + flowers, ferns, rocks, rails
  scripts/world/mountain_ring.gd     taller mountains
  scripts/world/world_manager.gd     shadows/glow follow the QUALITY setting
  scripts/pause_menu.gd              adds the QUALITY button (LOW / MEDIUM / HIGH), keeps TIME and FPS
  scripts/hud.gd                     FPS counter (same as the FPS update)
  shaders/tree_card.gdshader         trees sway in the wind
  shaders/mountains.gdshader         forest-like mountains
  shaders/terrain.gdshader           ground: fine detail and colour patches

NEW (2 scripts/shaders + 16 pictures)
  scripts/game_settings.gd           saves the QUALITY setting
  shaders/grass_card.gdshader        grass that sways
  assets/props/tree_card_c_0..2.png  olive-like tree        assets/props/tree_card_d_0..2.png  fir grove
  assets/props/tree_card_e_0..2.png  bush                   assets/props/tree_atlas_a..d.png   far-distance trees
  assets/props/grass_green / lush / dry / flowers_white / flowers_mixed .png

QUALITY (pause menu): LOW = close trees only, no grass, no shadows. MEDIUM = forest to 700 m, half the grass.
HIGH = forest to 1.3 km, full grass, tree shadows. Changing it restarts the level.
