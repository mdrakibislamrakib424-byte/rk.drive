RK DRIVE - PHASE 2 / STEP 3  (roadside world: trees, ferns, rocks, mountains, guard rails)
==========================================================================================
Upload every file to the GAME repo (the one that contains project.godot), into the SAME
folder as inside this zip. Do NOT upload this README.
These files come ON TOP of the 14 files of "RK_Drive_Phase2_FINAL.zip" (upload that first).

NEW FILES (15)
  scripts/world/scenery_builder.gd     trees, ferns, rocks, logs, road posts, guard rails
  scripts/world/mountain_ring.gd       distant mountains all around
  shaders/tree_card.gdshader           tree "card" material (sun / night aware)
  shaders/mountains.gdshader           mountain shape + colour
  assets/props/tree_card_a_0.png       tree pictures, variant A, three sides
  assets/props/tree_card_a_1.png
  assets/props/tree_card_a_2.png
  assets/props/tree_card_b_0.png       tree pictures, variant B, three sides
  assets/props/tree_card_b_1.png
  assets/props/tree_card_b_2.png
  assets/props/rocks_moss.glb          6 mossy rocks (3.5k triangles each)
  assets/props/log_dead.glb            fallen log (4.4k triangles)
  assets/props/stump.glb               tree stump (3k triangles)

REPLACE FILES (2)
  main.tscn                            adds the Scenery and Mountains nodes
  data/places/forest.tres              thinner fog (0.003 -> 0.0006) so the mountains can be seen

IMPORTANT: the "assets/props" files go in the GAME REPO (not in the GitHub Release).
Everything else (fern model, textures) already comes from the Release asset pack.
